﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml.Linq;

namespace XmlToMSSQLTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "XML Files |*.xml";
            if(openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtfilepath.Text = openFileDialog1.FileName;
            }
        }

        private void btnstart_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            string mystring = @"data source=" + txtserver.Text + ";initial catalog=" + txtdbname.Text + ";integrated security=true;";
            SqlConnection con = new SqlConnection(mystring);
            try
            {
                var cmdval="" ;
                ds.ReadXml(txtfilepath.Text);
                XDocument doc = XDocument.Load(txtfilepath.Text);
                dataGridView1.DataSource = ds.Tables[0];
                int colCount = dataGridView1.ColumnCount;
                con.Open();
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    cmdval = "";
                    for (int j = 0; j < colCount; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value.ToString() != "" )
                            cmdval += "N'"+ dataGridView1.Rows[i].Cells[j].Value.ToString() +"'"+ ",";
                        else
                            cmdval += "'No data',";
                    }
                    cmdval = cmdval.Remove(cmdval.Length - 1);
                    string mycmd = "Insert into " + txttablename.Text + " Values (" + cmdval + ");";
                    SqlCommand cmd = new SqlCommand(mycmd, con);
                   cmd.ExecuteNonQuery();
                }
                con.Close();
                MessageBox.Show("Rows Inserted Successfuly ");
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message.ToString());
               
            }
        }
    }
}
